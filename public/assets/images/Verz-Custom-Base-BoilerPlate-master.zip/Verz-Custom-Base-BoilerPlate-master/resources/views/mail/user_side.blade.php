@component('mail::message')
@component('mail::table')
{!! $data['contents'] !!}
@endcomponent
@endcomponent