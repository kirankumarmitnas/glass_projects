@extends('admin.layout.app')

@section('content')
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Welcome! You are logged in.</h1>
        </div>

        <div class="section-body">
        </div>
    </section>
</div>
@endsection
