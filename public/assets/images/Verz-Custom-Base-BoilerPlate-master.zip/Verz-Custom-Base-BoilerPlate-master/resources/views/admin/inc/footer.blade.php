<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; {{ date('Y') }} <a href="https://www.verzdesign.com/" target="_blank">Verz Design Pte Ltd</a>
    </div>
</footer>
