<?php


return [

    'admin_app_name'  =>  env('ADMIN_APP_NAME', 'Admin Panel'),

    'email_name'    =>  env('EMAIL_APP_NAME', 'Admin Email'),

    'pagination'    =>  20,
];
